<center class="maps container">
    <iframe src="https://www.google.com/maps/d/u/0/embed?mid=1Ydyvhp9ZOdh6yoE9egXrOE3uz2TtIr1Z" width="100%" height="480"></iframe>
</center>