<!-- Start register & login -->
<?php require_once 'login.php'; ?>
<?php require_once 'register.php'; ?>

<!-- Start Navbar -->
<?php require_once 'navbar.php'; ?>

<!-- Startd Header -->
<?php require_once 'header.php'; ?>

<!-- Footer -->
<?php require_once 'footer.php'; ?>
