<div class="slider">
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
            <img class="d-block w-100" src="https://s-media-cache-ak0.pinimg.com/originals/7f/af/82/7faf826666c2766d98ecbb2b55636e23.jpg" alt="First slide">
            </div>
            <div class="carousel-item">
            <img class="d-block w-100" src="https://i.ytimg.com/vi/TKDWP1jUfQE/maxresdefault.jpg" alt="Second slide">
            </div>
            <div class="carousel-item">
            <img class="d-block w-100" src="https://indaily.com.au/wp-content/uploads/2017/01/Uber_app_on_mobile_2_1200X720.jpg" alt="Third slide">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <center class="button_login">
        <h1 class="display-4">hello world!!</h1>
        <button type="button" class="btn btn-light m-1" onclick="on()">Sign Up</button>
    </center>
</div>