// Script Login & Register
function on() {
    document.getElementById("reg_box").style.display = "block";
    document.getElementById("login_box").style.display = "none";
}
function off() {
    document.getElementById("reg_box").style.display = "none";
}

function on_login() {
    document.getElementById("login_box").style.display = "block";
    document.getElementById("reg_box").style.display = "none";
}
function off_login() {
    document.getElementById("login_box").style.display = "none";
}

function res1() {
    document.getElementById("office1").style.display = "block";
}

function res2() {
    document.getElementById("office2").style.display = "block";
}


function res3() {
    document.getElementById("office3").style.display = "block";
}


function res4() {
    document.getElementById("office4").style.display = "block";
}

function res5() {
    document.getElementById("office5").style.display = "block";
}

function off_res() {
    document.getElementById("office1").style.display = "none";
    document.getElementById("office2").style.display = "none";
    document.getElementById("office3").style.display = "none";
    document.getElementById("office4").style.display = "none";
    document.getElementById("office5").style.display = "none";
}
